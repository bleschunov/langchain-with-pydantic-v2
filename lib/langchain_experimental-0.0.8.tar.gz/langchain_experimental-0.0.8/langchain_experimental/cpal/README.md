# Causal program-aided language (CPAL) chain


see https://github.com/hwchase17/langchain/pull/6255
